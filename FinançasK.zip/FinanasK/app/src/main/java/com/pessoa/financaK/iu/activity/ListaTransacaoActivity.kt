package com.pessoa.financaK.iu.activity

import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.pessoa.financaK.R
import com.pessoa.financaK.iu.adapter.LIstaTransacaoAdapter
import kotlinx.android.synthetic.main.activity_lista_transacao.*


class ListaTransacaoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_transacao)


        val transacoes = listOf(
            "Comida - R$ 20,50",
            "Economia - R$ 100,00"
        )

        lista_transacoes_listview.adapter = LIstaTransacaoAdapter(transacoes, this)
    }
}

//        val transacao = listOf("Comida - R$ 20,50",
//            "Economia - R$ 100,00")
//
//        val arrayAdapter = ArrayAdapter(this,android.R.layout.
//        simple_list_item_1, transacao)
//
//
//        lista_transacoes_listview.setAdapter(ListaTransacaoActivity(transacao, context))




